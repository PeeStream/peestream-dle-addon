<?php
/**
 * Shared, side-effect-free DLE AutoPublish identity and xfield mapping helpers.
 */
if ( ! function_exists( 'peestream_autopublish_identity_matches' ) ) {
	function peestream_autopublish_identity_matches( $fields, $payload, $config ) {
		$fields = is_array( $fields ) ? $fields : array();
		$season = isset( $payload['season'] ) ? max( 0, (int)$payload['season'] ) : 0;
		$episode = isset( $payload['episode'] ) ? max( 0, (int)$payload['episode'] ) : 0;
		$kind = isset( $payload['kind'] ) ? strtolower( (string)$payload['kind'] ) : '';
		$tmdb = isset( $payload['tmdb_id'] ) && ctype_digit( (string)$payload['tmdb_id'] ) ? (string)(int)$payload['tmdb_id'] : '';
		$imdb = isset( $payload['imdb_id'] ) && preg_match( '/^tt\d{5,12}$/i', (string)$payload['imdb_id'] ) ? (string)$payload['imdb_id'] : '';
		$names = array(
			'imdb' => ! empty( $config['xfield_imdb'] ) ? strtolower( (string)$config['xfield_imdb'] ) : 'imdb',
			'tmdb' => ! empty( $config['xfield_tmdb'] ) ? strtolower( (string)$config['xfield_tmdb'] ) : 'tmdb',
			'series' => ! empty( $config['xfield_tmdb_series'] ) ? strtolower( (string)$config['xfield_tmdb_series'] ) : 'tmdb_series_id',
			'season' => ! empty( $config['xfield_season'] ) ? strtolower( (string)$config['xfield_season'] ) : 'season',
			'episode' => ! empty( $config['xfield_episode'] ) ? strtolower( (string)$config['xfield_episode'] ) : 'episode',
		);
		$is_episode = 'episode' === $kind || ( $season > 0 && $episode > 0 );
		if ( $is_episode ) {
			return '' !== $tmdb && isset( $fields[$names['series']], $fields[$names['season']], $fields[$names['episode']] )
				&& (string)$fields[$names['series']] === $tmdb
				&& (string)$fields[$names['season']] === (string)$season
				&& (string)$fields[$names['episode']] === (string)$episode;
		}
		return ( '' !== $imdb && isset( $fields[$names['imdb']] ) && strcasecmp( trim( (string)$fields[$names['imdb']] ), $imdb ) === 0 )
			|| ( '' !== $tmdb && isset( $fields[$names['tmdb']] ) && (string)$fields[$names['tmdb']] === $tmdb );
	}
}

if ( ! function_exists( 'peestream_autopublish_event_key' ) ) {
	function peestream_autopublish_event_key( $event_id ) {
		return 'v2_' . substr( hash( 'sha256', (string)$event_id ), 0, 28 );
	}
}

if ( ! function_exists( 'peestream_autopublish_release_event' ) ) {
	function peestream_autopublish_release_event( $db, $table, $event_id ) {
		if ( ! is_object( $db ) || ! method_exists( $db, 'query' ) || ! method_exists( $db, 'safesql' ) ) return false;
		$safe_id = $db->safesql( (string)$event_id );
		return (bool)$db->query( "DELETE FROM {$table} WHERE event_id = '{$safe_id}'", false );
	}
}

if ( ! function_exists( 'peestream_autopublish_approval_state' ) ) {
	function peestream_autopublish_approval_state( $config ) {
		return ! empty( $config['moderate_new_posts'] ) && '1' === (string)$config['moderate_new_posts'] ? 0 : 1;
	}
}

if ( ! function_exists( 'peestream_autopublish_map_xfields' ) ) {
	function peestream_autopublish_map_xfields( $fields, $payload, $config ) {
		$fields = is_array( $fields ) ? $fields : array();
		$code = isset( $payload['file_code'] ) ? trim( (string)$payload['file_code'] ) : '';
		if ( ! preg_match( '/^[a-zA-Z0-9_-]{1,64}$/', $code ) ) return $fields;
		$names = array(
			'imdb' => ! empty( $config['xfield_imdb'] ) ? strtolower( (string)$config['xfield_imdb'] ) : 'imdb',
			'tmdb' => ! empty( $config['xfield_tmdb'] ) ? strtolower( (string)$config['xfield_tmdb'] ) : 'tmdb',
			'series' => ! empty( $config['xfield_tmdb_series'] ) ? strtolower( (string)$config['xfield_tmdb_series'] ) : 'tmdb_series_id',
			'season' => ! empty( $config['xfield_season'] ) ? strtolower( (string)$config['xfield_season'] ) : 'season',
			'episode' => ! empty( $config['xfield_episode'] ) ? strtolower( (string)$config['xfield_episode'] ) : 'episode',
		);
		$player = ! empty( $config['xfield_player'] ) ? strtolower( (string)$config['xfield_player'] ) : ( ! empty( $config['xfield_name'] ) ? strtolower( (string)$config['xfield_name'] ) : 'peestream' );
		$source = ! empty( $config['xfield_source_code'] ) ? strtolower( (string)$config['xfield_source_code'] ) : 'peestream_code';
		$domain = ! empty( $config['player_domain'] ) ? rtrim( (string)$config['player_domain'], '/' ) : 'https://peeplayer.com';
		$url = isset( $payload['player_url'] ) && 0 === strpos( (string)$payload['player_url'], 'https://' )
			? (string)$payload['player_url'] : $domain . '/e/' . rawurlencode( $code );
		$fields[$source] = $code;
		$fields[$player] = ! empty( $config['xfield_player'] )
			? '<iframe src="' . htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' ) . '" loading="lazy" allowfullscreen style="width:100%;aspect-ratio:16/9;border:0"></iframe>'
			: $code;
		$legacy = ! empty( $config['xfield_name'] ) ? strtolower( (string)$config['xfield_name'] ) : 'peestream';
		if ( $legacy !== $player && $legacy !== $source ) $fields[$legacy] = $code;
		$imdb = isset( $payload['imdb_id'] ) && preg_match( '/^tt\d{5,12}$/i', (string)$payload['imdb_id'] ) ? (string)$payload['imdb_id'] : '';
		$tmdb = isset( $payload['tmdb_id'] ) && ctype_digit( (string)$payload['tmdb_id'] ) ? (string)(int)$payload['tmdb_id'] : '';
		if ( '' !== $imdb && empty( $fields[$names['imdb']] ) ) $fields[$names['imdb']] = $imdb;
		$is_episode = isset( $payload['kind'] ) && 'episode' === strtolower( (string)$payload['kind'] );
		if ( '' !== $tmdb ) $fields[$is_episode ? $names['series'] : $names['tmdb']] = $tmdb;
		if ( $is_episode ) {
			$fields[$names['season']] = isset( $payload['season'] ) ? (string)max( 0, (int)$payload['season'] ) : '0';
			$fields[$names['episode']] = isset( $payload['episode'] ) ? (string)max( 0, (int)$payload['episode'] ) : '0';
		}
		return $fields;
	}
}
